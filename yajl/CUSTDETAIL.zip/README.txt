These files contain the RPG and DDS code for this example.  The custfile.pf.txt file should be uploaded to a QDDSSRC file on your IBM i, and the custdetail.sqlrpgle.txt to a QRPGLESRC file on your IBM i.

Information about dependencies and how to compile the source code can be found at the top of the source files.
