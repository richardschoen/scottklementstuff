This is the STOCKQTY Sample Program from the article

"Serve Up JSON Web Services with RPG and YAJL" by Scott Klement, published in the July 2013 issue
of iPro Developer magazine.

This ZIP file contains two items:

1) PRODUCTSP.sql is the source code for the PRODUCTSP physical file.  Upload this (or copy/paste via RDi) into a source member on your system and run it with RUNSQLSTM to create the PF.

2) STOCKQTY.rpgle is the source code for the STOCKQTY web service.  Upload this (or copy/paste via RDi) into a source member on your system, and compile it using the instructions at the top of the source member.

The article will describe how to install this as a web service.
