WORKING WITH JSON IN RPG (WITH YAJL) SAMPLE CODE
(c) Copyright 2014, Scott Klement
------------------------------------------------

This is the sample code for the "Working with JSON in RPG" presentation by Scott Klement. The JSONWEBSRV example is intended to run on the IBM i HTTP Server (powered by Apache) using the techiques described in another presentation called "Providing Web Services on IBM i".

You can get handouts for either of these two presentations, here:
http://www.scottklement.com/presentations/

All of the included samples require the IBM i port of YAJL to be installed. You can find YAJL here:
http://www.scottklement.com/yajl/


Here are the sample programs provided:

JSONWRITE.sqlrpgle
------------------
This is an example of generating JSON data from RPG. It illustrates outputting a document that is a list of invoices found for a customer in a date range. The list is output in JSON format.

The JSON data is written to a stream file (in the IFS) named /tmp/example.json


JSONWEBSRV.sqlrpgle
-------------------
This sample program generates the same JSON as the preceding program, except that it is meant by be called as a REST web service. It gets it's parameters from a URL, and outputs the JSON data to the HTTP server to be sent on to a web service client (or AJAX program.)

It is intended to be used with the REST techniques described in the presentation called "Providing Web Services on IBM i"


JSONREAD1.rpgle
---------------
This demonstrates reading JSON data from an IFS file in RPG. It illustrates reading elements from an array of objects.  Subfields within the objects are retrieved by their field names.

The JSON data is loaded into a data structure suitable for display from a program debugger.


JSONREAD2.rpgle
---------------
This is the same as JSONREAD1, except that the objects in the array are read using the YAJL_OBJECT_LOOP utility.  Also, after loading the data into the data structure, this example will generate a simple printout (using O-specs to a print file.)

