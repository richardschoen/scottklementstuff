This is an IBM i port of the YAJL JSON Parser and Generator by Lloyd Hilaiel

This was ported to IBM i by Scott Klement <yajl@scottklement.com>, and contains RPG language bindings also created by Scott Klement.

YAJL's official home page is here:
http://lloyd.github.io/yajl/

The IBM i port is hosted here:
http://www.scottklement.com/yajl

-----------------------------------------------------------------------------------
TO INSTALL PRECOMPILED VERSION WITHOUT DATA-INTO SUPPORT (recommended for pre-V7R2)
-----------------------------------------------------------------------------------

The file named YAJLLIB.SAVF contains a save file with both the YAJL service program and the YAJLR4 service program already compiled and ready to use.  It requires IBM i 6.1, minimum level.

To restore, use FTP with these commands:

ftp your-ibmi-system
(sign in)
quote rcmd CRTSAVF QGPL/YAJLLIB
binary
put YAJLLIB.SAVF QGPL/YAJLLIB
quote rcmd CRTLIB YAJL
quote rcmd RSTOBJ OBJ(*ALL) SAVLIB(QTEMP) DEV(*SAVF) RSTLIB(YAJL) SAVF(QGPL/YAJLLIB)
quit

This will create a library named YAJL containing all of the needed objects.  To use a different library, simply specify a different name on the CRTLIB and RSTLIB(xxx) options, above.


-----------------------------------------------------------------------------------
TO INSTALL PRECOMPILED VERSION WITH DATA-INTO/DATA-GEN SUPPORT 
       (recommended for V7R2+)
-----------------------------------------------------------------------------------

The file named YAJLLIB72.SAVF contains a save file with both the YAJL service program and the YAJLR4 service program already compiled and ready to use.  It requires IBM i 7.2, minimum level, and the PTFs that enable the RPG DATA-INTO opcode for that release.

Information about DATA-INTO PTFs for V7R2/V7R3 can be found at the following link:
http://ibm.biz/data-into-rpg-opcode-ptfs

(No additional PTFs are needed for DATA-INTO on 7.4 or newer.)

Information about DATA-GEN PTFs for V7R3/V7R4 can be found here:
http://ibm.biz/fall_2019_rpg_enhancements

Although the DATA-GEN program can be restored to V7R2, it will not run unless you are on V7R3 or newer with the above PTFs installed.

To restore, use FTP with these commands:

ftp your-ibmi-system
(sign in)
quote rcmd CRTSAVF QGPL/YAJLLIB72
binary
put YAJLLIB72.SAVF QGPL/YAJLLIB72
quote rcmd CRTLIB YAJL
quote rcmd RSTOBJ OBJ(*ALL) SAVLIB(QTEMP) DEV(*SAVF) RSTLIB(YAJL) SAVF(QGPL/YAJLLIB72)
quit

This will create a library named YAJL containing all of the needed objects.  To use a different library, simply specify a different name on the CRTLIB and RSTLIB(xxx) options, above.


-----------------------------------------------------------------------------------
TO INSTALL ALL SOURCES AND BUILD FROM SOURCE:
-----------------------------------------------------------------------------------

This process is not required.  If you prefer to simply install the precompiled objects
see "TO INSTALL PRECOMPILED VERSION", above. 

If you do wish to follow this process (for example, if you are a developer who wishes to make improvements/modifications to YAJL), then you will need both an ILE RPG compiler and an ILE C compiler.  The C code for YAJL is stored in the IFS and installed from the YAJLIFS.ZIP file.  The RPG and CL code is kept in the YAJLLIB.SAVF file.

Here are the steps to build from source:

1) Restore the RPG/CL source code from the YAJLLIB.SAVF file:


ftp your-ibmi-system
(sign in)
quote rcmd CRTSAVF QGPL/YAJLLIB
binary
put YAJLLIB.SAVF QGPL/YAJLLIB
quote rcmd CRTLIB YAJL
quote rcmd RSTOBJ OBJ(QCLSRC QSRVSRC QRPGLESRC YAJL) SAVLIB(QTEMP) DEV(*SAVF) 
             RSTLIB(YAJL) SAVF(QGPL/YAJLLIB)
quit

To use a different library, put your library name in place of 'YAJL' in the CRTLIB and RSTLIB parameters, above.

2) Restore the C source code from the YAJLIFS.ZIP file:

ftp your-ibmi-system
(sign in)
quote site namefmt 1
cd /tmp
binary
put YAJLIFS.ZIP
quit

3) Unzip the YAJLIFS.ZIP file.  This may be done using a mapped drive from Windows, or if you have the "unzip", "jar", or "7-zip" tool, you can do it from the IBM i.

This example illustrates doing it with 7-zip from PASE:

CALL QP2TERM
cd /
7z x /tmp/YAJLIFS.ZIP

This creates a directory named /yajl off of the root of your IFS, it contains both the original source from Lloyd Hilaiel, and the IBM i port from Scott Klement.

To do the same from a different Zip tool, just make sure you unzip to the /yajl directory of your IFS.  The /yajl directory should contain subdirectories named "extras", "include", "orig" and "Working" after the unzip is complete.

4) Use the BUILDYAJL CL program to compile the YAJL and YAJLR4 service programs.

    a) First edit the YAJL/QCLSRC,BUILDYAJL member.  It's a standard CL program, and you can
        edit it with RDi, SEU, or your favorite source member editor.

    b) Look for the DCL lines for &buildlib, &srcdir, &incdir, and &tgtrls variables. Change
        these to the library, IFS directories, and target release that you prefer.  
        (The shipped version assumes you are using the YAJL library and the /yajl IFS dir.)

    c) Also look for &debug. Changing &debug to '1' will make a debuggable copy
        of YAJL -- note that this runs slower than a non-debugable copy.

    d) Also look for &teraspace. Changing &teraspace to '1' will allocate memory
        in teraspace, allowing JSON documents larger than 16 mb in size.

    e) Compile the program with:
        CRTBNDCL YAJL/BUILDYAJL SRCFILE(YAJL/QCLSRC)

    f) Call the program with:
        CALL YAJL/BUILDYAJL

   When complete, you should have *SRVPGMs named YAJL and YAJLR4, as well as a YAJL binding
   directory in your YAJL library.            

-----------------------------------------------------------------------------------
SAMPLE PROGRAMS:
-----------------------------------------------------------------------------------

The YAJL suite comes with two programs, a JSON verifier and a JSON reformatter. 
These are also compiled into the YAJL library by the BUILDYAJL program.  They are,
unfortunately, cumbersome to use on IBM i due to the implicit ASCII/EBCDIC translation
that the system performs.  They are interesting to study from a C programming example
of how to use YAJL. however.

However I will be publishing samples of using YAJL from within RPG programs on my web site
http://www.scottklement.com/yajl
