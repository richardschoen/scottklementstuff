#!/bin/sh
FTPSCRIPT=clubtech.fts
HOST=$1
LIB=$2
USER=$3
PASS=$4

usage() {
   echo " "
   echo "USAGE: ./ftpsrc.sh HOST LIB USERID PASSWORD"
   echo " "
   echo "     HOST = FTP server to send to (ex: as400.example.com)"
   echo "      LIB = IBM i library to put source code into (ex: QGPL)"
   echo "   USERID = UserID to log in with"
   echo " PASSWORD = Password to log in with"
   echo " "
}

buildscript() {
   echo "user $USER $PASS"
   echo "cd /qsys.lib/qgpl.lib"
   echo "quote site namefmt 0"
   echo "quote rcmd crtsrcpf file($LIB/QRPGLESRC) rcdlen(112)"
   echo "quote rcmd crtsrcpf file($LIB/QSRVSRC) rcdlen(92)"
   echo "ascii"
   echo "put csv_h.rpgle $LIB/QRPGLESRC.csv_h"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csv_h) srctype(rpgle)"
   echo "ascii"
   echo "put csvdemo.rpgle $LIB/QRPGLESRC.csvdemo"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvdemo) srctype(rpgle)"
   echo "ascii"
   echo "put csvdemo2.rpgle $LIB/QRPGLESRC.csvdemo2"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvdemo2) srctype(rpgle)"
   echo "ascii"
   echo "put csvdemo3.rpgle $LIB/QRPGLESRC.csvdemo3"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvdemo3) srctype(rpgle)"
   echo "ascii"
   echo "put csvdemo4.rpgle $LIB/QRPGLESRC.csvdemo4"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvdemo4) srctype(rpgle)"
   echo "ascii"
   echo "put csvdemo5.rpgle $LIB/QRPGLESRC.csvdemo5"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvdemo5) srctype(rpgle)"
   echo "ascii"
   echo "put csvinto.rpgle $LIB/QRPGLESRC.csvinto"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvinto) srctype(rpgle)"
   echo "ascii"
   echo "put csvr4.rpgle $LIB/QRPGLESRC.csvr4"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvr4) srctype(rpgle)"
   echo "ascii"
   echo "put csvtest.rpgle $LIB/QRPGLESRC.csvtest"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(csvtest) srctype(rpgle)"
   echo "ascii"
   echo "put iconv_h.rpgle $LIB/QRPGLESRC.iconv_h"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(iconv_h) srctype(rpgle)"
   echo "ascii"
   echo "put ifsio_h.rpgle $LIB/QRPGLESRC.ifsio_h"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(ifsio_h) srctype(rpgle)"
   echo "ascii"
   echo "put csvr4.bnd $LIB/QSRVSRC.csvr4"
   echo "quote rcmd chgpfm file($LIB/QSRVSRC) mbr(csvr4) srctype(bnd)"
   echo "quit"
}

if test "x$HOST" = "x" -o "x$LIB" = "x" -o "x$USER" = "x" -o "x$PASS" = "x"; then
  usage
  exit 1
fi

buildscript > $FTPSCRIPT
ftp -n $HOST < $FTPSCRIPT
rm -f $FTPSCRIPT
