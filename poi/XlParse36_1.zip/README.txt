Utilities/Interfaces for Parsing Excel Spreadsheets with the EventModel of POI
by Scott Klement

For more information about this programming example, please see the following
article on System iNetwork:
http://systeminetwork.com/article/new-xlparser4-tool-supports-xlsx-format

-----------------------------------------------------------------------------
UPLOAD INSTRUCTIONS:
-----------------------------------------------------------------------------

This article contains a handy FTP script to help you upload the source code 
from your PC to your IBM i system.  The script is called ftpsrc.bat.  
To run it, type the following from an MS-DOS prompt:

   ftpsrc.bat HOST LIB USER PASSWORD

Where:   HOST = the TCP/IP host name or IP address of your system.
          LIB = library to upload the source code to
         USER = your userid to log on to FTP with
     PASSWORD = your password to log on to FTP with

For example, if you unzipped this code into the C:\Downloads folder on your PC, you'd open a Command Prompt (MS-DOS prompt) and type:

   C:
   cd \Downloads
   ftpsrc.bat as400.example.com xlparse36 scottk bigboy

This would connect to as400.example.com and log on as userid scottk, password
bigboy.  It would then upload the source code to the XLPARSE36 library on that 
system.

Note: There's also an ftpsrc.sh shell script for FreeBSD users.  (Unfortunately
      I don't know if it's compatible with other Unix-like systems such as
      Linux.)

-----------------------------------------------------------------------------
MANUAL UPLOAD INSTRUCTIONS:
-----------------------------------------------------------------------------

If you are unable to use the FTP upload script, you can also upload the source
members using any other tool that you have available.  The members are 
expected to be uploaded as follows:

PC source file        IBM i source file     source member
--------------        -------------------   -------------
buildxlp.clp     ->   xlparse36/qclsrc      buildxlp
xlparser4.bnd    ->   xlparse36/qsrvsrc     xlparser4
xlparse_h.rpgle  ->   xlparse36/qrpglesrc   xlparse_h
xlparser4.rpgle  ->   xlparse36/qrpglesrc   xlparser4
xlpdemo.rpgle    ->   xlparse36/qrpglesrc   xlpdemo
xlpdemof.rpgle   ->   xlparse36/qrpglesrc   xlpdemof
xlpnotdemo.rpgle ->   xlparse36/qrpglesrc   xlpnotdemo

The following should be uploaded in BINARY mode to your IFS:

PC file                 Suggested IBM i IFS pathname
-----------------       --------------------------------------------
xlparse-src.jar     ->   /java/xlparse3.6/xlparse-src.jar
xlparse.jar         ->   /java/xlparse3.6/xlparse.jar
xlpdemo.xls         ->   /tmp/xlpdemo.xls
xlpdemo.xlsx        ->   /tmp/xlpdemo.xlsx
TestFormula.xls     ->   /tmp/TestFormula.xls
TestFormula.xlsx    ->   /tmp/TestFormula.xlsx
november_sales.xls  ->   /tmp/november_sales.xls
november_sales.xlsx ->   /tmp/november_sales.xlsx


-----------------------------------------------------------------------------
BUILD/COMPILE INSTRUCTIONS:
-----------------------------------------------------------------------------
Once you've uploaded everything, you can use the BUILDXLP CL program to
compile it.  The BUILDXLP program assumes that the source files will be
found in your library list, and that the objects should be created in the
current library (*CURLIB)

Therefore to create the tools & demo programs, you should follow these steps:

     CRTLIB LIB(XLPARSE36)

   - do the upload, as above, then -

     CHGLIBL  LIBL(QGPL QTEMP) CURLIB(XLPARSE36)
     CRTCLPGM BUILDXLP SRCFILE(QCLSRC)
     CALL BUILDXLP

The utilities are in the XLPARSER4 service program. 

The sample programs are named XLPDEMO, XLPDEMOF, and XLPNOTDEMO.
You can simply CALL them to try them out.

Pass the sample programs a parameter of '1' to tell them to use XSSF instead of the default HSSF support.

For example:
     CALL PGM(XLPDEMO) PARM('1')
