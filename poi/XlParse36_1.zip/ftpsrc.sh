#!/bin/sh
FTPSCRIPT=clubtech.fts
HOST=$1
LIB=$2
USER=$3
PASS=$4

usage() {
   echo " "
   echo "USAGE: ./ftpsrc.sh HOST LIB USERID PASSWORD"
   echo " "
   echo "     HOST = FTP server to send to (ex: as400.example.com)"
   echo "      LIB = IBM i library to put source code into (ex: QGPL)"
   echo "   USERID = UserID to log in with"
   echo " PASSWORD = Password to log in with"
   echo " "
}

buildscript() {
   echo "user $USER $PASS"
   echo "cd /qsys.lib/qgpl.lib"
   echo "quote site namefmt 0"
   echo "quote rcmd crtsrcpf file($LIB/QCLSRC) rcdlen(92)"
   echo "quote rcmd crtsrcpf file($LIB/QRPGLESRC) rcdlen(112)"
   echo "quote rcmd crtsrcpf file($LIB/QSRVSRC) rcdlen(92)"
   echo "ascii"
   echo "put buildxlp.clp $LIB/QCLSRC.buildxlp"
   echo "quote rcmd chgpfm file($LIB/QCLSRC) mbr(buildxlp) srctype(clp)"
   echo "ascii"
   echo "put xlparse_h.rpgle $LIB/QRPGLESRC.xlparse_h"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(xlparse_h) srctype(rpgle)"
   echo "ascii"
   echo "put xlparser4.rpgle $LIB/QRPGLESRC.xlparser4"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(xlparser4) srctype(rpgle)"
   echo "ascii"
   echo "put xlpdemo.rpgle $LIB/QRPGLESRC.xlpdemo"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(xlpdemo) srctype(rpgle)"
   echo "ascii"
   echo "put xlpdemof.rpgle $LIB/QRPGLESRC.xlpdemof"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(xlpdemof) srctype(rpgle)"
   echo "ascii"
   echo "put xlpnotdemo.rpgle $LIB/QRPGLESRC.xlpnotdemo"
   echo "quote rcmd chgpfm file($LIB/QRPGLESRC) mbr(xlpnotdemo) srctype(rpgle)"
   echo "ascii"
   echo "put xlparser4.bnd $LIB/QSRVSRC.xlparser4"
   echo "quote rcmd chgpfm file($LIB/QSRVSRC) mbr(xlparser4) srctype(bnd)"
#  ---------------------------------------------------------------
#  --          The following commands added by hand             --
#  ---------------------------------------------------------------
   echo "quote site namefmt 1"
   echo "mkdir /java"
   echo "mkdir /java/xlparse3.6"
   echo "cd /java/xlparse3.6"
   echo "prompt off"
   echo "binary"
   echo "mput *.jar"
   echo "cd /tmp"
   echo "mput *.xls"
   echo "mput *.xlsx"
#  ---------------------------------------------------------------
#  --          end of commands added by hand                    --
#  ---------------------------------------------------------------
   echo "quit"
}

if test "x$HOST" = "x" -o "x$LIB" = "x" -o "x$USER" = "x" -o "x$PASS" = "x"; then
  usage
  exit 1
fi

buildscript > $FTPSCRIPT
ftp -n $HOST < $FTPSCRIPT
rm -f $FTPSCRIPT
