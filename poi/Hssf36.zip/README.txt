Utilities/Interfaces for Using HSSF/XSSF/POI from ILE RPG 
by Scott Klement

For more information about this programming example, please see the following
article on System iNetwork:
http://systeminetwork.com/article/new-poi-release-brings-excels-xlsx-support-rpg

-----------------------------------------------------------------------------
UPLOAD INSTRUCTIONS:
-----------------------------------------------------------------------------

This article contains a handy FTP script to help you upload the source code 
from your PC to your IBM i system.  The script is called ftpsrc.bat.  
To run it, type the following from an MS-DOS prompt:

   ftpsrc.bat HOST LIB USER PASSWORD

Where:   HOST = the TCP/IP host name or IP address of your system.
          LIB = library to upload the source code to
         USER = your userid to log on to FTP with
     PASSWORD = your password to log on to FTP with

For example, if you unzipped this code into the C:\Downloads folder on your PC, you'd open a Command Prompt (MS-DOS prompt) and type:

   C:
   cd \Downloads
   ftpsrc.bat as400.example.com poi36 scottk bigboy

This would connect to as400.example.com and log on as userid scottk, password
bigboy.  It would then upload the source code to the POI36 library on that 
system.

Note: There's also an ftpsrc.sh shell script for FreeBSD users.  (Unfortunately
      I don't know if it's compatible with other Unix-like systems such as
      Linux.)

-----------------------------------------------------------------------------
MANUAL UPLOAD INSTRUCTIONS:
-----------------------------------------------------------------------------

If you are unable to use the FTP upload script, you can also upload the source
members using any other tool that you have available.  The members are 
expected to be uploaded as follows:

PC source file        IBM i source file     source member
--------------        -------------------   -------------
buildhssf.clp    ->   poi36/qclsrc          buildhssf
divsales.sql     ->   poi36/qsqlsrc         divsales
hssfr4.bnd       ->   poi36/qsrvsrc         hssfr4
addpic.rpgle     ->   poi36/qrpglesrc       addpic
colordemo.rpgle  ->   poi36/qrpglesrc       colordemo
hdrdemo.rpgle    ->   poi36/qrpglesrc       hdrdemo
hssf_h.rpgle     ->   poi36/qrpglesrc       hssf_h
hssfr4.rpgle     ->   poi36/qrpglesrc       hssfr4
ifsio_h.rpgle    ->   poi36/qrpglesrc       ifsio_h
upddemo.rpgle    ->   poi36/qrpglesrc       upddemo
xlcrtdemo.rpgle  ->   poi36/qrpglesrc       xlcrtdemo

-----------------------------------------------------------------------------
BUILD/COMPILE INSTRUCTIONS:
-----------------------------------------------------------------------------
Once you've uploaded everything, you can use the BUILDHSSF CL program to
compile it.  The BUILDHSSF program assumes that the source files will be
found in your library list, and that the objects should be created in the
current library (*CURLIB)

Therefore to create the tools & demo programs, you should follow these steps:

     CRTLIB LIB(POI36)

   - do the upload, as above, then -

     CHGLIBL  LIBL(QGPL QTEMP) CURLIB(POI36)
     CRTCLPGM BUILDHSSF SRCFILE(QCLSRC)
     CALL BUILDHSSF

The utilities are in the HSSFR4 service program. 

The sample programs are named XLCRTDEMO, COLORDEMO, HDRDEMO, ADDPIC, and 
UPDDEMO.  You can simply CALL them to try them out.

Pass the sample programs a parameter of '1' to tell them to use XSSF instead of the default HSSF support.

For example:
     CALL PGM(XLCRTDEMO) PARM('1')
